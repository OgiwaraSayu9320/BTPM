package btpm;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
//import thuattoan.Bellmanford.Graph.Edge;

import model.Graph;

public class Bellmanford extends javax.swing.JFrame {

    public Bellmanford() {
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNguon = new javax.swing.JTextField();
        txtDich = new javax.swing.JTextField();
        txtGiatri = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtKetqua = new javax.swing.JTextField();
        btnTinh = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtHienthi = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        btnThoat = new javax.swing.JButton();
        btnNhap = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblmatran = new javax.swing.JTable();
        btnLuu = new javax.swing.JButton();
        btnTu = new javax.swing.JTextField();
        btnDen = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bellman Ford");

        jLabel1.setText("Nguồn:");

        jLabel2.setText("Đích: ");

        jLabel3.setText("Đường đi ngắn nhất là: ");

        jLabel4.setText("Giá trị: ");

        btnTinh.setText("Tính");
        btnTinh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTinhActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        txtHienthi.setColumns(20);
        txtHienthi.setRows(5);
        jScrollPane1.setViewportView(txtHienthi);

        jLabel5.setText("Hiển thị:");

        btnThoat.setText("Thoát");
        btnThoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThoatActionPerformed(evt);
            }
        });

        btnNhap.setText("Nhập");
        btnNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNhapActionPerformed(evt);
            }
        });

        tblmatran.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nguồn", "Đích", "Giá trị"
            }
        ));
        jScrollPane2.setViewportView(tblmatran);

        btnLuu.setText("Lưu");
        btnLuu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLuuActionPerformed(evt);
            }
        });

        jLabel6.setText("Đến:");

        jLabel7.setText("Từ:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(52, 52, 52)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtKetqua, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtDich)
                                .addComponent(txtGiatri, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                                .addComponent(txtNguon)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(btnNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(54, 54, 54)
                                    .addComponent(btnLuu, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(56, 56, 56)
                                    .addComponent(btnTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel7)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnTu, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(37, 37, 37)
                                    .addComponent(jLabel6)
                                    .addGap(28, 28, 28)
                                    .addComponent(btnDen, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnThoat, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtNguon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtDich, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtGiatri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel7)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnTu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)
                                    .addComponent(btnDen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(39, 39, 39)
                        .addComponent(txtKetqua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTinh)
                    .addComponent(btnCancel)
                    .addComponent(btnThoat)
                    .addComponent(btnNhap)
                    .addComponent(btnLuu))
                .addGap(61, 61, 61))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThoatActionPerformed
        if(evt.getSource()==btnThoat){
            System.exit(0);
        }
        
    }//GEN-LAST:event_btnThoatActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        try {
            txtNguon.setText("");
            txtDich.setText("");
            txtGiatri.setText("");
            txtHienthi.setText("");
            txtKetqua.setText("");
            DefaultTableModel tbl = (DefaultTableModel) tblmatran.getModel();
            tbl.setRowCount(NORMAL);
            //  tblmatran.clearSelection();
            btnTu.setText("");
            btnDen.setText("");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Lỗi!!!");
            txtDich.requestFocus();
        }
    }//GEN-LAST:event_btnCancelActionPerformed


    private void btnNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNhapActionPerformed
        if (evt.getSource() == btnNhap) {
            String s1 = txtNguon.getText();
            String s2 = txtDich.getText();
            String s3 = txtGiatri.getText();
            String s4 = "-->";
            if (s1.isEmpty() || s2.isEmpty() || s3.isEmpty()) {
                JOptionPane.showMessageDialog(btnNhap, "bạn chưa nhập thông tin!");
            } else {
                try {
                    txtHienthi.append(s1 + s4 + s2 + " là: " + s3 + "\n");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_btnNhapActionPerformed

    private void btnTinhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTinhActionPerformed
        /*if (evt.getSource() == btnTinh) {

            if (btnTu.getText().isEmpty() || btnDen.getText().isEmpty()) {
                JOptionPane.showMessageDialog(btnTinh, "bạn chưa nhập dữ liệu!");
            }
        } else {*/
            int start = Integer.parseInt(btnTu.getText());
            int end = Integer.parseInt(btnDen.getText());

            if (evt.getSource() == btnTinh) {
                DefaultTableModel tbl = (DefaultTableModel) tblmatran.getModel();
                // lay so dinh 
                int v = 0;
                for (int i = 0; i < tbl.getRowCount(); i++) {
                    v = Math.max(v, Integer.parseInt(tbl.getValueAt(i, 0).toString()));
                    v = Math.max(v, Integer.parseInt(tbl.getValueAt(i, 1).toString()));
                }
                // khoi tao do thi
                Graph g = new Graph(v);
                for (int i = 0; i < tbl.getRowCount(); i++) {
                    int src = Integer.parseInt(tbl.getValueAt(i, 0).toString());
                    int dest = Integer.parseInt(tbl.getValueAt(i, 1).toString());
                    int weight = Integer.parseInt(tbl.getValueAt(i, 2).toString());
                    g.addEdge(src, dest, weight);
                }

                int[] pathLength = Graph.BellmanFord(g, start);
                if (pathLength[0] == -1) {
                    txtKetqua.setText("Chu trinh am");
                } else {
                    txtKetqua.setText(Integer.toString(pathLength[end]));
                }
                
                if(Integer.parseInt(txtKetqua.getText())<0){
                    txtKetqua.setText("");
                    JOptionPane.showMessageDialog(btnTinh, "Chu trình âm!");
                    
                }
            }
       // }
    }//GEN-LAST:event_btnTinhActionPerformed

    private void btnLuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLuuActionPerformed
        String data[] = {txtNguon.getText(),
            txtDich.getText(), txtGiatri.getText()};
        DefaultTableModel tbl = (DefaultTableModel) tblmatran.getModel();
        tbl.addRow(data);

        txtNguon.setText("");
        txtDich.setText("");
        txtGiatri.setText("");
    }//GEN-LAST:event_btnLuuActionPerformed

    public void hienthi() {
        //String s="";
        //s=(txtNguon.setText("")+)
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Bellmanford().setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JTextField btnDen;
    private javax.swing.JButton btnLuu;
    private javax.swing.JButton btnNhap;
    private javax.swing.JButton btnThoat;
    private javax.swing.JButton btnTinh;
    private javax.swing.JTextField btnTu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblmatran;
    private javax.swing.JTextField txtDich;
    private javax.swing.JTextField txtGiatri;
    private javax.swing.JTextArea txtHienthi;
    private javax.swing.JTextField txtKetqua;
    private javax.swing.JTextField txtNguon;
    // End of variables declaration//GEN-END:variables

}
