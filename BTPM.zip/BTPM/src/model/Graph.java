package model;

import java.util.ArrayList;

// A class to represent a connected, directed and weighted graph
public class Graph {
    // A class to represent a weighted edge in graph
    public class Edge {
        public int src, dest, weight;
        Edge()
        {
            src = dest = weight = 0;
        }
        Edge(int src, int dest, int weight){
        	this.src = src;
        	this.dest = dest;
        	this.weight = weight;
        }
        public int getWeight(){
        	return this.weight;
        }
    };
  
    int V, E;
    ArrayList<Edge> edge = new ArrayList<Edge>();
  
    // Creates a graph with V vertices and E edges
    public Graph(int v)
    {
        this.V = v;
        this.E = 0;
    }
    public void addEdge(int src, int dest, int weight) {
    	Edge e = new Edge(src, dest, weight);
    	this.edge.add(e);
    	this.E++;
    }
    
    
    // The main function that finds shortest distances from src
    // to all other vertices using Bellman-Ford algorithm. The
    // function also detects negative weight cycle
    public static int[] BellmanFord(Graph graph, int src)
    {
        int V = graph.V, E = graph.E;
        int dist[] = new int[V+1];
  
        // Step 1: Initialize distances from src to all other
        // vertices as INFINITE
        for (int i = 0; i <= V; ++i)
            dist[i] = Integer.MAX_VALUE;
        dist[0] = 1;
        dist[src] = 0;
  
        // Step 2: Relax all edges |V| - 1 times. A simple
        // shortest path from src to any other vertex can
        // have at-most |V| - 1 edges
        for (int i = 1; i < V; ++i) {
            for (int j = 0; j < E; ++j) {
                int u = graph.edge.get(j).src;
                int v = graph.edge.get(j).dest;
                int weight = graph.edge.get(j).weight;
                if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v])
                {
                	dist[v] = dist[u] + weight;
                }
                
            }
        }
        for (int j = 0; j < E; ++j) {
            int u = graph.edge.get(j).src;
            int v = graph.edge.get(j).dest;
            int weight = graph.edge.get(j).weight;
            if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v])
            {
            	// phat hien chu trinh am
            	dist[0] = -1;
                System.out.print("chu trình âm");
            }
            
        }
        return dist;
    }
}